import mongoose from "mongoose";
import dotenv from "dotenv"

dotenv.config();

mongoose.set("strictQuery", true);
let dbConnect =async ()=> {
    try{
const connected = await mongoose.connect(process.env.MONGO_URL);
console.log(`Mongodb connected ${ connected.connection.host}`);

    }catch(err){
console.log(`Error : ${err.message}`) //to display the error message
//to exit the application
process.exit(1)
    }
 
}

export default  dbConnect;


