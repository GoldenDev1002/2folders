import mongoose  from "mongoose";
let userSchema = mongoose.Schema;

let eachUserSchema = new userSchema({
    fullName: {
        type: String,
        required: true
    },

    email: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },

    order : [ {
        type: mongoose.Schema.Types.ObjectId, // referencing the id of each collection
        ref: "Order" // referencing the order model
    } ], 

    wishList : [ {
        type: mongoose.Schema.Types.ObjectId, // referencing the id of each collection
        ref: "WishList" // referencing the wishlist model
    } ], 

    isAdmin: {
        type:Boolean,
        default: false
    },

    //shipping address to the frontend

    hasShippingAddress: {
        type:Boolean,
        default: false
    },

    isAdmin: {
        type:Boolean,
        default: false
    },

    shippingAddress :{
        firstName : {
            type: String
        },

        lastName : {
            type:String
        },

        address : {
            type:String
        },

        city : {
            type:String
        },

        postalCode : {
            type:String
        },

        province : {
            type:String
        },

        country : {
            type:String
        },

        phone: {
            type: String
        }



    }


}, {timestamps: true})

const User = mongoose.model("User", eachUserSchema)

export default User;