export const globalErrHandler = async(err, req, res, next)=> {
    //stack -> the line of code where the error occured
    //message

    const stack = err?.stack;
    const message = err?.message;
    const statusCode = err?.statusCode ? err?.statusCode : 500 //if th euser provided the status code or provide 500

    res.status(statusCode).json({
        stack,
        message
    })
}


//404 handler

export const notFound = async(req, res, next)=> {
    const err = new Error (`Route ${req.originalUrl} cannot be found`); //creating a custome message , the orginsalurl means the url that the user is accessing
    next(err)
}
