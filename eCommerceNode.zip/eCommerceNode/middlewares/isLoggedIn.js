import { getTokenFromHeader } from "../utils/getTokenFromHeader.js"
import {  verifyToken } from "../utils/verifyToken.js";



export const isLoggedIn = async(req, res, next)=> {
    //getToken from header
  const token =  getTokenFromHeader(req);
  //verify the token form header
  const decodedUser = verifyToken(token);
  //save the user to the database
  if(!decodedUser){
    throw new Error('Invalid/Expired token, please login again ')
  }else{
    //to save the verified user in the request object
    req.userAuthId = decodedUser?.id;
    next()
  }


}