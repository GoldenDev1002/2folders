import express from "express";
import {createNewProducts, getProductCtrl} from "../controllers/productCtrl.js";
import { isLoggedIn } from "../middlewares/isLoggedIn.js";

const productRouter = express.Router();
//the user needs to be logged in to access the products
productRouter.post("/", isLoggedIn, createNewProducts );

//if the user isn;t logged in, he can access all the products
productRouter.get("/", getProductCtrl );

export default productRouter