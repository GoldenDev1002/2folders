import express from "express";
import { registerUserCtrl , loginController, userController} from "../controllers/userCtrl.js";
import { isLoggedIn } from "../middlewares/isLoggedIn.js";

const userRoutes = express.Router();
userRoutes.post("/login", loginController)
userRoutes.post("/register", registerUserCtrl)
userRoutes.get("/profile", isLoggedIn, userController)

export default userRoutes

