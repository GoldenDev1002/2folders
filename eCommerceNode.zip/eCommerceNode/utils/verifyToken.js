
import jwt from "jsonwebtoken";

export const verifyToken = (token)=> { //the token that is going to be verified
//returns true or false to determine whether the token is verified
return jwt.verify(token, process.env.JWT_TOKEN, (err, decoded)=> {//should contain the token to be verified and the token's key stored in JWT_TOKEN
//if there is an error
if(err){
    return false
}else{
    return decoded // returns the user
}
}); 

}
