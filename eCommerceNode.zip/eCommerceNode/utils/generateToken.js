/*import jwt from "jsonwebtoken";

const generateToken = (id)=> { //the id of the user to generate that token
//the payload token
return jwt.sign({id}, process.env.JWT_TOKEN, {expiresIn: "3d"}) //id represents the user id, 2nd parameter represents the key for the token , 3rd represents when the token will expire
}

export default generateToken */


import jwt from "jsonwebtoken";

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_TOKEN, { expiresIn: "3d" });
};

export default generateToken;

