export const getTokenFromHeader = (req)=> { //pass in the entire request project
const token = req?.headers?.authorisation?.split(" ")[1]; //split the entire authentication token

//if the token doesn't exist 
if(token === undefined){
    return "No token is found in the header"
}else{
    return token
}
}