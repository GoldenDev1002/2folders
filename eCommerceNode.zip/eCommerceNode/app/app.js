import express from "express"
import dbConnect from "../config/dbConnect.js" //whenever module is used pas sin the extension
import userRoutes from "../routes/userRoute.js"
import { globalErrHandler, notFound } from "../middlewares/globalErrHandler.js";
import productRouter from "../routes/productRoute.js";



dbConnect();
const expressApp = express();
expressApp.get("/", (req, res)=> {
    res.send("<p>To the next center </p>")
})

//to pass incoming data

expressApp.use(express.json())
expressApp.use("/app/v1/users/", userRoutes)
expressApp.use("/app/v1/products/", productRouter);
//not found object is placed on top 
expressApp.use(notFound)
//error middleware needs be placed below the routes because it catches the errors
expressApp.use(globalErrHandler)
export default expressApp