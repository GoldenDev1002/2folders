import expressApp from "./app/app.js"
import http from "http";

const portNo= process.env.PORT || 7000;
const server = http.createServer(expressApp);

server.listen(portNo, console.log(`server is up and running ${portNo}`));