import User from "../model/user.js";
import bcrypt from "bcryptjs"
import asyncHandler from "express-async-handler";
import generateToken from "../utils/generateToken.js";
import { getTokenFromHeader } from "../utils/getTokenFromHeader.js";
import { verifyToken } from "../utils/verifyToken.js";



//@desc Register user
//@route POST api/v1/users/register
// @acess Admin -> the developer will provide acces to the admin



export const registerUserCtrl = async (req, res)=> {
  let {fullName, email, password} = req.body

  //to check if a user exists
  let userExists = await User.findOne({email});
  if(userExists){
   return res.json({
        msg: "The user exists"
    })
  }
  //hash password

// a salt is a random string of charcters that makes the password unpredictible
const salt = await bcrypt.genSalt(10) //gives us a random string of charcters, the higher the characters in d parameter, the more secure the password
const hashedPassword = await bcrypt.hash(password, salt)

  //if ther is no user with a particular email
  const userFound = await User.create(req.body, {
    fullName,
    email,
    password:hashedPassword
  })

  res.status(201).json({
    status: "Success",
    register: "User registered successfully",
    data: userFound,
    token: generateToken(userFound?._id)
  })



}


export const loginController = asyncHandler (async(req, res)=> {
  // the user can only log in if the email and password matches the ones saved in the database

  let {email, password} = req.body;
  //checks if the user is found using an email
  const userFound = await User.findOne({email});
//if the user isn't found
  if( password && await bcrypt.compare(password, userFound?.password)){ //optional chaining
    //awaiting for the the password to be compared with the hashed password that is stored in the database using bcrypt

    return res.json({
      msg: "the user is stored in the database"
    })

  }
else{
 throw new Error ('Invalid login credentials');
}

})

//@desc get user profile
//@route get api/v1/user/profile
//@access private

export const userController = async(req, res)=> {
  let generateToken = getTokenFromHeader(req) //passing the request object as the token is being generated
  let verifyToken = verifyToken(generateToken)


  res.json({
    msg: "to the user controller"
  })
}
