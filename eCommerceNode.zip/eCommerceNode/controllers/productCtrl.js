import asynchandler from "express-async-handler"
import ProductModel from "../model/product.js"

//@desc -> Create new product
//@route -> POST api/v1/products
//@acess -> Private/Admin

export const createNewProducts = asynchandler(async(req, res)=> {
const {name, description, category, sizes, colors, user, reviews, price, totalQty, totalSold } = req.body
//checking if the logged in user is an admin

//checking if a particular product exists
const ProductExists = ProductModel.findOne({name});

//if the product doesn't exist
if(ProductExists){
    throw new Error("This product already exists")
}

//create the products

let products = await ProductModel.create({
    name,
    description,
    category, 
    sizes,
    colors,
    user: req.userAuthId,  // the logged in user will create the product
    reviews, 
    price, 
    totalQty, 
    totalSold 
})

// push products into category
// send response

res.json({
    status: "success",
    message : "product created successfully",
    products
})



})

//@desc -> Create new product
//@route -> POST api/v1/products
//@acess -> Public


export const getProductCtrl = asynchandler(async(req, res)=> {
//display all the products
let products = await ProductModel.find();

// status message when all the products are displayed


res.json({
    status: 200,
    message : "All the products are displayed",
    products
})



})