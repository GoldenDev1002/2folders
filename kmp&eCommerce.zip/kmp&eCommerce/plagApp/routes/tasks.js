let express = require("express");
let routerApp = express.Router();

let {
    getAllTasks,
    getTask,
    createTask,
    updateTask,
    deleteTask
    }  = require("../controllers/pageRoute.js")
    

routerApp.route("/").get(getAllTasks).post(createTask);
routerApp.route("/:id").get(getTask).put(updateTask).delete(deleteTask);


module.exports = routerApp;