let express = require("express");
let app = express();
let bodyParser = require("body-parser");
app.use(express.json())
//routes
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.use(express.urlencoded({extended: false}));


let cors = require("cors");
let connection = require("./db/connection");
let path = require("path");
let pathFile = path.resolve(__dirname, "publicFile");
app.use(express.static(pathFile));
let routes = require("./routes/tasks")
app.use(cors());
app.set("view engine", "ejs" );
app.set("views", "webPage")


require("dotenv").config()

app.get("/show", (req, res)=> {
res.send("to the next homepage")
})

app.use("/route", routes)

let showProject = async()=> {
    try{
     await connection(process.env.MONGO_URL)
    app.listen("4600", ()=> {
        console.log("this is to 4600 server");
    })
}catch(err){
    console.log("err")
}
}


showProject();