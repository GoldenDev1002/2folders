let documentModel = require("../models/model");

let  getAllTasks = async (req, res)=> {
    try{
    let getTask = await documentModel.find().sort({createdAt: -1});
    res.status(201).render("home", {documents: getTask})
    }catch(err){
     res.status(500).json(err)
    }

}


let createTask = async (req, res)=> {
    console.log(req.body)
    try{
       let createTask = new documentModel({
        title: req.body.title
        
    }
  
       )
        createTask.save()
        .then((connect)=> {
            res.status(201).json({connect})
            //render("taskManager",{blog: connect})
        })
        }catch(err){
         res.status(500).json(err)
        }
    

}

let updateTask = async (req, res)=> {
  let {id: TaskID} = req.params
    try{
        
        let updatedTask = await documentModel.findOneAndUpdate({_id: TaskID},  req.body, {
            new: true,
            runValidators: true
        })
        res.status(201).json(updatedTask)

    }catch(err){
       res.status(500).json(err)
    }

}




let deleteTask =  (req, res)=>{
    const id = req.params.id;

    //fing each document by its individual id and delete it
    documentModel.findByIdAndDelete(id)
    .then(result => {
        //WHEN WE SEWND A REQUEST BY THE FETCH API, IT CANNOT BE REDIRECTED IN NODE UNLESS D DATA IS CONVERTED TO JSON AND REDIRECTED BACK TO THE BROWSER
     //redirecting to the allblogs page after a blog has been deleted
     res.json({redirect:"/routes"})   
    })
    .catch((err)=> {
        console.log(err);
    })
}


let getTask = async (req, res)=> {
    let id = req.params.id;
    try{
      let eachTask = await documentModel.findById(id);
        res.status(201).render("details",  {detail: eachTask})

    }catch(err){
       res.status(500).json(err)
    }

}

let createTaskPage = (req, res)=> {
    res.status(201).render("create");
}


module.exports = {
    getAllTasks,
    createTask,
    updateTask,
    deleteTask, 
    createTaskPage,
    getTask
}
