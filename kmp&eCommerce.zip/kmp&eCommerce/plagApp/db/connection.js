let mongoose = require("mongoose");
mongoose.set("strictQuery", true);

let connectionLink = (url)=> {
mongoose.connect(url, {useNewUrlParser: true, useUnifiedTopology: true})
.then((connect)=> {
    console.log("connected to the db..." + connect)
})
.catch((err)=>{
    console.log(err);
})



}

module.exports = connectionLink;