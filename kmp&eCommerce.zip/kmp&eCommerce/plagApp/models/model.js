let mongoose = require("mongoose");
let pageSchema = mongoose.Schema;

let eachPage = new pageSchema({
    title:String

}, {timestamps: true})


let eachModel = mongoose.model("plagiarismdatabases", eachPage);

module.exports = eachModel;