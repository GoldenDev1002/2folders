let mongoose = require("mongoose");
let schema = mongoose.Schema;

let loginSchema = new schema({

    user : {
        type : String,
        required: true
    },

    password : {
        type : String,
        required: true
    }

}, {timestamps : true})

let loginModel = mongoose.model("collection1", loginSchema);

module.exports = loginModel;