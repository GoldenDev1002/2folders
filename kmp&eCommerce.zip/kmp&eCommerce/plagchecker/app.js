let express = require("express");
let app = express();
let mongoose = require("mongoose");
let loginModel = require("./structure.js");

let portNo = 3800;
let dbUrl = "mongodb+srv://WebstoreUser1:Ngozi2001!@webstorecluster1.g6wampr.mongodb.net/test"
mongoose.set("strictQuery", true);
mongoose.connect(dbUrl, {useNewUrlParser: true, useUnifiedTopology: true})
.then((result)=> {
    app.listen(portNo, ()=> {
        console.log("this is to the port 3800");
    })
})
.catch((err)=> {
    console.log(err);
})
app.use(express.static("public"));
app.set("view engine", "ejs");


app.get("/login", (req , res)=> {
    res.render("login", {title: "Plagchecker"})
})


app.get("/index", (req, res)=> {
    res.render("index", {title: "Index Page"})
})

app.get("/user", (req, res)=> {
    

    let newUser = new loginModel({
        user : "Simibatu",
        password : "IamSimz"
    })

    newUser.save()
    .then((response)=> {
        res.send(response)
    })
    .catch((err)=> {
        console.log(err);
    })
})


app.get("/singleUser", (req, res)=> {
    loginModel.findById("63b4fbaad208166e0c3e0610")
    .then((eachUser)=>{
        res.send(eachUser)
    })
    .catch((err)=> {
        console.log(err);
    })
})

app.get("/allUsers", (req, res)=> {
    loginModel.find()
    .then((eachUser)=>{
        res.render("index", {user:eachUser})
    })
    .catch((err)=> {
        console.log(err);
    })


})

app.get("/allUsers/:id", (req, res)=> {
    let id = req.params.id;
    loginModel.findById(id)
    .then((eachUser)=> {
        res.render(index, {user:eachUser})
    })
    .catch((err)=> {
     console.log(err)
    })
})