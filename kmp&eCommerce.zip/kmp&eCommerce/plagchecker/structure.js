let mongoose = require("mongoose");
let schemas = mongoose.Schema;

let loginSchema = new schemas({

user: {
    type: String,
    required: true
},
password: {
    type: String,
    required : true

}



}, {timestamps: true})

let loginModel = mongoose.model("collection1", loginSchema);

module.exports = loginModel;