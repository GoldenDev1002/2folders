let express = require("express");
let app = express();
let mongoose = require("mongoose");
mongoose.set("strictQuery", true);
let dbUrl = "mongodb+srv://WebstoreUser1:Ngozi2001!@webstorecluster1.g6wampr.mongodb.net/test";
mongoose.connect(dbUrl, {useUnifiedTopology: true, useNewUrlParser: true})
.then((connect)=> {
    app.listen("1100", ()=> {
        console.log("this is for the server 1110");
    })
    
})
.catch((err)=> console.log(err));

let loginModel = require("./structure2.js");
app.use(express.urlencoded({extended: true}));

app.use(express.static("public"));
app.set("view engine", "ejs");

app.get("/", (req, res)=> {
    res.redirect("/allUsers")
})

app.get("/singleUser", (req, res)=> {
    let eachUser = new loginModel({
        user: "new user 8",
        password: "12345hjebfebf"
    })

    eachUser.save()
    .then((connect)=> res.send(connect))
    .catch((err)=> console.log(err));
})


app.get("/oneUser",(req, res)=> {
    loginModel.findById("63b9b5934426745f1b5d10ef")
    .then((connect)=> res.send(connect))
    .catch((err)=> console.log(err));
})

app.get("/allUsers",(req, res)=> {
    loginModel.find().sort({createdAt: -1})
    .then((connect)=> res.render("index2", {blogs: connect}))
    .catch((err)=> console.log(err));
})

app.get("/login", (req, res)=> {
    res.render("login", {title: "Login"});
})

app.post("/allUsers", (req, res)=> {
    let formData = new loginModel((req.body));
    formData.save()
    .then((newform) => res.redirect("/"))
    .catch((err)=> console.log(err))
})



app.get("/allUsers/:id", (req, res)=> {
    let id = req.params.id;
    loginModel.findById(id)
    .then((connect)=> res.render("details", {blog: connect}))
    .catch((err)=> console.log(err));

})

app.delete("/allUsers/:id", (req, res)=> {
    let id = req.params.id;
    loginModel.findByIdAndDelete(id)
    .then((connect)=> res.json({redirect : "/allUsers"}))
    .catch((err)=> console.log(err));

})


app.get("/index", (req, res)=> {
   res.render("index2") 
})


app.use((req, res, next)=> {
    res.status(404).render("404");
    next();
})



