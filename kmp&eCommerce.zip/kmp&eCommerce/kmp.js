i // i represents the flow
WELCOME TO LONDON

LONDON
j  //j represents LONDON



a = total length of substring in WELCOME TO LONDON
b = total length of pattern LONDON

O(ba) // total time taken for the naive algorithm  o represents order

i = 0
WELCOME COME TO LONDON

01234567
ELAPCELO 
00000120 
01234567891011
ABC ABCDAB ABCDABCDABDE

0123456
ABCDABD
0000120 //LPS TABLE

01200000010000000000//line 5 COMPARED AGAINST LINE 2

00012301234
COME

01234567
ELAPCELO 
00000120 //COMPARED AGAINST ELAPCELO


abcd abcdba abbcdt abcdbba

abcdbba



j= 1
LONDON
 00000

 LONDON // WITH O AS THE FIRST CHARCTER FOR COMPARISON
 00010
//kmp algorithm 


WELCOME TO LONDON
           LONDON


    abcd abcdba abbcdt abcdabb

    0123456 
    abcdabb
    0000120



    function kmpSearch(text, pattern) {
       let lps = computeLPS(pattern);
       let i = 0; // index for text
       let j = 0; // index for pattern
       let indices = [];
     
       while (i < text.length) {
         if (text[i] === pattern[j]) {
           i++;
           j++;
         }
     
         if (j === pattern.length) {
           indices.push(i - j);
           j = lps[j - 1];
         } else if (i < text.length && text[i] !== pattern[j]) {
           if (j !== 0) {
             j = lps[j - 1];
           } else {
             i++;
           }
         }
       }
     
       return indices;
     }
     
     // computing the lps
     function computeLPS(pattern) { 
       let lps = Array(pattern.length).fill(0); //the array holds the lps values, pattern refrs to the lps pattern, fill replaces all the lements in the array with 0
       let len = 0; //stores the number of match 
       let i = 1; //denotes the first charcter of the pattern
     
       while (i < pattern.length) {
         if (pattern[i] === pattern[len]) { //the second character compared to the first charcter matching the prefix and suffix
           len++; //when there's a match the length increases meaning in jenny , e will be the next chacter in comparison
           lps[i] = len; 
           i++;
         } else {
           if (len !== 0) {
             len = lps[len - 1];
           } else {
             lps[i] = 0;
             i++;
           }
         }
       }
     
       return lps;
     }


     